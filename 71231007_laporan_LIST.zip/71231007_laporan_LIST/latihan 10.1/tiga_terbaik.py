def tiga_terbaik(data):
    if len(data) < 3:
        raise ValueError("List harus memiliki minimal 3 elemen.")
    unik = list(set(data))
    unik.sort(reverse=True)
    return unik[:3]

angka = [15, 3, 9, 22, 7, 22, 18]
print(tiga_terbaik(angka))  # Output: [22, 18, 15]