def hitung_rata_rata():
    bilangan = []
    while True:
        masukan = input("Masukkan bilangan (atau 'done' untuk selesai): ")
        if masukan.lower() == "done":
            break
        try:
            bilangan.append(float(masukan))
        except ValueError:
            print("Input tidak valid, masukkan bilangan atau 'done'.")
    
    if bilangan:
        rata_rata = sum(bilangan) / len(bilangan)
        print(f"Rata-rata: {rata_rata:.2f}")
    else:
        print("Tidak ada bilangan yang dimasukkan.")

hitung_rata_rata()