import string  # Mengimpor modul string untuk mengakses tanda baca
import os      # Mengimpor modul os untuk mengakses lokasi file

# Mendefinisikan fungsi kata_unik dengan parameter nama_file
def kata_unik(nama_file):
    try:
        # Membuka file teks dengan mode baca ('r') dan encoding utf-8
        with open(nama_file, 'r', encoding='utf-8') as f:
            teks = f.read()  # Membaca seluruh isi file dan disimpan ke variabel teks
        
        # Menghapus semua tanda baca dari teks dan menggantinya dengan spasi
        for tanda in string.punctuation:
            teks = teks.replace(tanda, ' ')
        
        # Mengubah semua huruf menjadi kecil lalu memisahkan kata-kata menjadi list
        semua_kata = teks.lower().split()
        
        # Menghapus kata yang duplikat dengan set(), lalu diurutkan A-Z dengan sorted()
        unik = sorted(set(semua_kata))
        
        # Menampilkan jumlah total kata unik yang ditemukan
        print(f"Total kata unik: {len(unik)}")
        
        # Menampilkan satu per satu kata unik yang ditemukan
        for kata in unik:
            print(kata)
    
    # Jika file tidak ditemukan, tampilkan pesan error
    except FileNotFoundError:
        print("File tidak ditemukan.")

# Mengambil lokasi folder tempat file kata_unik.py berada
folder = os.path.dirname(os.path.abspath(__file__))

# Menggabungkan lokasi folder dengan nama file artikel.txt
path_artikel = os.path.join(folder, "artikel.txt")

# Memanggil fungsi kata_unik dengan path lengkap file artikel.txt
kata_unik(path_artikel)